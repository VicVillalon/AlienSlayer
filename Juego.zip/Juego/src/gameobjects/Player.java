package gameobjects;

import java.awt.Graphics;
import java.awt.image.BufferedImage;

import input.KeyBoard;
import math.Vector2D;

// Clase jugador que implementa el gameobject
public class Player extends GameObject {

	// Constructor
	public Player(BufferedImage texture, Vector2D position) {
		super(texture, position);
	}

	// Actualización de la posicion del jugador
	@Override
	public void update() {
		if (KeyBoard.RIGHT) {
			position.setX(position.getX() + 5);
		}
		if (KeyBoard.LEFT) {
			position.setX(position.getX() - 5);
		}
		if (KeyBoard.UP) {
			position.setY(position.getY() - 5);
		}
		if (KeyBoard.DOWN) {
			position.setY(position.getY() + 5);
		}

	}

	// Se dibuja al jugador a partir de la posicion actualizada
	@Override
	public void draw(Graphics gp) {
		// TODO Auto-generated method stub
		gp.drawImage(texture, (int) position.getX(), (int) position.getY(), null);
	}

}
