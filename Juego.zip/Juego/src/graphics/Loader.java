package graphics;

import java.awt.image.BufferedImage;
import java.io.IOException;

import javax.imageio.ImageIO;

// Clase que carga los recursos de la imagen
public class Loader {
	// Carga la imagen a partir de la ruta pasada por parametro
	public static BufferedImage ImageLoader(String path) {
		try {
			return ImageIO.read(Loader.class.getResource(path));
		} catch (IOException e) {
			e.printStackTrace();
		}
		return null;
	}
}
