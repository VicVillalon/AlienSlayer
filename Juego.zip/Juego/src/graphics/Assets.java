package graphics;

import java.awt.image.BufferedImage;

// Clase que recoge todas las imagenes para dibujarlas en la ventana
public class Assets {

	public static BufferedImage player;

	// Metodo que inicia la carga de imagenes
	public static void init() {
		player = Loader.ImageLoader("/personajes/player.png");
	}
}
