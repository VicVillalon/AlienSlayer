package graphics;

import java.awt.image.BufferedImage;

// Clase que recoge todas las imagenes para dibujarlas en la ventana
public class Assets {

	public static BufferedImage player;

	public static BufferedImage speed;

	public static BufferedImage disparo, greenLaser, redLaser;

	public static BufferedImage[] bigs = new BufferedImage[4];
	public static BufferedImage[] meds = new BufferedImage[2];
	public static BufferedImage[] smalls = new BufferedImage[2];
	public static BufferedImage[] tinies = new BufferedImage[2];

	public static BufferedImage escenario;

	// Metodo que inicia la carga de imagenes
	public static void init() {
		player = Loader.ImageLoader("/personajes/player.png");

		speed = Loader.ImageLoader("/efectos/fire.png");

		disparo = Loader.ImageLoader("/shoots/disparo.png");

		greenLaser = Loader.ImageLoader("/shoots/laserGreen.png");

		redLaser = Loader.ImageLoader("/shoots/laserRed.png");

		for (int i = 0; i < bigs.length; i++) {
			bigs[i] = Loader.ImageLoader("/meteors/big" + (i + 1) + ".png");
		}
		for (int i = 0; i < meds.length; i++) {
			meds[i] = Loader.ImageLoader("/meteors/med" + (i + 1) + ".png");
		}
		for (int i = 0; i < smalls.length; i++) {
			smalls[i] = Loader.ImageLoader("/meteors/small" + (i + 1) + ".png");
		}
		for (int i = 0; i < tinies.length; i++) {
			tinies[i] = Loader.ImageLoader("/meteors/tiny" + (i + 1) + ".png");
		}

		escenario = Loader.ImageLoader("/escenario/escenario.png");

	}
}
