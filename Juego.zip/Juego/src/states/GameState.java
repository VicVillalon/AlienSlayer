package states;

import java.awt.Graphics;

import gameobjects.Player;
import graphics.Assets;
import math.Vector2D;

// Juego que guarda en todo momento el estado del juego, se encarga de actualizar, dibujar, etc.. Todos los objetos del juego
public class GameState {

	private Player player;

	// Constructor que inicia los objetos del juego dandoles la posicion y los
	// graficos
	public GameState() {
		player = new Player(Assets.player, new Vector2D(100, 500));

	}

	// Actualizacion de posicion de los objetos
	public void update() {
		player.update();
	}

	// Dibuja en la ventana los objetos
	public void draw(Graphics gp) {
		// TODO Auto-generated method stub
		player.draw(gp);
	}

}
