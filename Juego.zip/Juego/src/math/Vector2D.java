package math;

// Clase que comprende la posicion a partir de vectores (x) y (y)
public class Vector2D {
	private double x, y;

	// Constructor donde le pasamos por parametro la posicion
	public Vector2D(double x, double y) {
		this.x = x;
		this.y = y;
	}

	// Constructor por defecto donde nos inicia la posicion en 0,0
	public Vector2D() {
		x = 0;
		y = 0;
	}

	public double getX() {
		return x;
	}

	public void setX(double x) {
		this.x = x;
	}

	public double getY() {
		return y;
	}

	public void setY(double y) {
		this.y = y;
	}

}
