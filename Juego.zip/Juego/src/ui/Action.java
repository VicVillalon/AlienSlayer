package ui;

public interface Action {

	public abstract void doAction();

}
