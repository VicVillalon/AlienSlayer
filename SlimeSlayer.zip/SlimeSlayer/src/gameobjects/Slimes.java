package gameobjects;

import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.geom.AffineTransform;
import java.awt.image.BufferedImage;

import graphics.Assets;
import graphics.Sound;
import math.Vector;
import stages.GameStage;
import stages.MenuStage;

/**
 * Clase abstracta para los slimes
 * 
 * @author Víctor Villalón
 * @version 1.0
 */
public abstract class Slimes extends GameObject {
	private Sound slimeSound;

	/**
	 * Constructor base de los slimes
	 * 
	 * @param texture   Imagen que tendrá el slime
	 * @param position  Vector posición en el que aparecerá
	 * @param maxVel    Velocidad máxima a la que se mueve
	 * @param velocity  Vector velocidad que tiene
	 * @param gameStage Pantalla del juego en la que aparece
	 * 
	 */

	public Slimes(BufferedImage texture, Vector position, double maxVel, Vector velocity, GameStage gameStage) {
		super(texture, position, maxVel, velocity, gameStage);
		slimeSound = new Sound(Assets.slimeSound);
		if (MenuStage.muted) {
			slimeSound.mute();
		} else {
			slimeSound.changeVolume(-8.0f);
		}

	}

	/**
	 * Método para ir actualizando su posición en función de la velocidad, siguiendo
	 * como patrón la posición del jugador
	 */
	@Override
	public void update() {
		position = position.add(velocity);
		Vector playerPosition = gameStage.getPlayer().getCenter().substract(getCenter());
		velocity = velocity.add(playerPosition);
		velocity = velocity.limit(maxVel);
		position = position.add(velocity);
		angle = setAngleSlime(gameStage.getPlayer().getCenter(), position);

	}

	@Override
	public void destroy() {
		slimeSound.play();
		super.destroy();

	}

	/**
	 * Método para generar la posición en la que mira el slime
	 * 
	 * @param positionSlime  Vector posición del slime
	 * @param positionPlayer Vector posición del jugador
	 * @return double Cuantos grados tiene que rotar para mirar al jugador
	 */
	public double setAngleSlime(Vector positionSlime, Vector positionPlayer) {
		double tangentarc, substractX, substractY;
		substractY = positionSlime.getY() - positionPlayer.getY();
		substractX = positionSlime.getX() - positionPlayer.getX();
		tangentarc = Math.atan2(substractY, substractX);

		// Para la rotación de los slimes el método probado fue este
//		if (substractY > 0 && substractX > 0) {
//			// Slime debajo(y) izquierda(x)
//			System.out.println("soy arriba izquierda");
//			return 90 + tangentarc;
//		}
//		if (substractY < 0 && substractX > 0) {
//			// Slime abajo(y) izquierda(x)
//			System.out.println("soy abajo izquierda");
//			return tangentarc + 90;// 90-tangentarc + 180
//		}
//		if (substractY > 0 && substractX < 0) {
//			// Slime arriba(y) derecha(x)
//			System.out.println("soy arriba derecha");
//			return 90 + tangentarc;
//		}
//		// Slime abajo(y) derecha(x)
//		System.out.println("soy abajo derecha");
		return tangentarc + 90;
	}

	/**
	 * Método para dijuar los slime
	 * 
	 * @param gp Recurso para dibujar los slimes
	 */
	@Override
	public void draw(Graphics gp) {

		Graphics2D g2d = (Graphics2D) gp;

		at = AffineTransform.getTranslateInstance(position.getX(), position.getY());
		at.rotate(angle, width / 2, height / 2);
		g2d.drawImage(texture, at, null);
	}

	/**
	 * Método para multiplicar la puntuación que da el slime al coger el power up
	 * 
	 * @param score Puntuación original del slime
	 * @return int Nueva puntuación
	 */
	public int doubleScore(int score) {
		if (Player.doubleScoreOn) {
			return score * 2;
		}
		return score;
	}

	/**
	 * Método para eliminar de un disparo a todos los slimes al coger el power up
	 * 
	 * @return boolean Sí esta activo o no
	 */
	public boolean instakill() {
		if (Player.instakillOn) {
			return true;
		}
		return false;
	}

}
