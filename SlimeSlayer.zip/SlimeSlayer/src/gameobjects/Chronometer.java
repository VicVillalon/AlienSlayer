package gameobjects;

/**
 * Esta clase simula un cronómetro para temporizar diferentes eventos
 * 
 * @author Víctor Villalón
 * 
 * @version 1.0
 *
 */

public class Chronometer {

	private long diff, lastTime;
	private long time;
	private boolean running;

	/**
	 * Constructor de la clase, que inicializa a 0 la diferencia de tiempo y coge la
	 * hora actual en milisegundos
	 * 
	 */
	public Chronometer() {
		diff = 0;
		lastTime = System.currentTimeMillis();
		running = false;
	}

	/**
	 * Inicia el cronómetro
	 * 
	 * @param time Es el tiempo que tiene que cronometrar
	 */
	public void run(long time) {
		running = true;
		this.time = time;
	}

	/**
	 * Método que va actualizando la diferencia de tiempo mientras comprueba que no
	 * se pasa del tiempo límite
	 */
	public void update() {
		if (running) {
			diff += System.currentTimeMillis() - lastTime;
		}
		if (diff >= time) {
			running = false;
			diff = 0;
		}

		lastTime = System.currentTimeMillis();
	}

	/**
	 * Método para saber sí el cronmetro está en marcha o no
	 * 
	 * @return boolean Indica sí está en activo o no.
	 */
	public boolean isRunning() {
		return running;
	}
}
