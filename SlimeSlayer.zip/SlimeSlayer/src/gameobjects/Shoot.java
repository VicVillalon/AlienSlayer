package gameobjects;

import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.geom.AffineTransform;
import java.awt.image.BufferedImage;

import math.Vector;
import stages.GameStage;
import window.MainWindow;

/**
 * Clase para los disparos
 * 
 * @author Javier VAlero
 * @version 1.0
 */
public class Shoot extends GameObject {

	/**
	 * Constructor del disparo
	 * 
	 * @param texture   Imagen de la bala
	 * @param position  Vector posición
	 * @param maxVel    Máxima velocidad
	 * @param angle     Angulo de la bala
	 * @param velocity  Vector velocidad de la bala
	 * @param gameStage Pantalla del juego en la que aparece
	 */
	public Shoot(BufferedImage texture, Vector position, double maxVel, double angle, Vector velocity,
			GameStage gameStage) {
		super(texture, position, maxVel, velocity, gameStage);
		this.angle = angle;
		this.velocity = velocity.scale(maxVel);
	}

	/**
	 * Método para actualizar la posición de la bala según la posición que lleva
	 */
	@Override
	public void update() {
		position = position.add(velocity);
		if (position.getX() < 0 || position.getX() > MainWindow.WIDTH || position.getY() < 0
				|| position.getY() > MainWindow.HEIGHT) {
			gameStage.getMovingObjects().remove(this);

		}
		collidesWith();
	}

	/**
	 * Método para dibujar la bala
	 */
	@Override
	public void draw(Graphics gp) {
		Graphics2D g2d = (Graphics2D) gp;
		at = AffineTransform.getTranslateInstance(position.getX() - width / 2 + 13, position.getY() - 20);

		at.rotate(angle, width / 2 - 13, 20);

		g2d.drawImage(texture, at, null);

	}

	/**
	 * Método para coger el centro de la bala
	 */
	@Override
	public Vector getCenter() {
		return new Vector(position.getX() + width / 2, position.getY() + width / 2);
	}

}
