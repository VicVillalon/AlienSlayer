package gameobjects;

import java.awt.image.BufferedImage;

import math.Vector;
import stages.GameStage;

/**
 * Clase del Slime rápido
 * 
 * @author Víctor Villalón
 * @version 1.0
 */
public class SlimeFast extends Slimes {

	private static final int SLIME_SCORE = 100;

	/**
	 * Constructor del slime
	 * 
	 * @param texture   Imagen que tendrá el slime
	 * @param position  Vector posición en el que aparecerá
	 * @param maxVel    Velocidad máxima a la que se mueve
	 * @param velocity  Vector velocidad que tiene
	 * @param gameStage Pantalla del juego en la que aparece
	 */
	public SlimeFast(BufferedImage texture, Vector position, double maxVel, Vector velocity, GameStage gameStage) {
		super(texture, position, maxVel, velocity, gameStage);

	}

	/**
	 * Método sobreescrito añadiendo la puntuación del slime y destruyéndolo
	 */
	@Override
	public void destroy() {
		gameStage.addScore(super.doubleScore(SLIME_SCORE), position);
		super.destroy();
	}

}
