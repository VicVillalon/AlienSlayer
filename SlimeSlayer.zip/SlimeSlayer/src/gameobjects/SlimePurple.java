package gameobjects;

import java.awt.image.BufferedImage;

import graphics.Assets;
import math.Vector;
import stages.GameStage;

/**
 * Clase de los slimes morados que se dividen
 * 
 * @author Víctor Villalón
 *
 */
public class SlimePurple extends Slimes {

	private static final int SLIME_SCORE = 25;
	private static final int MINISLIME_SCORE = 5;
	private static boolean slimePurple;

	/**
	 * Constructor del slime
	 * 
	 * @param texture   Imagen que tendrá el slime
	 * @param position  Vector posición en el que aparecerá
	 * @param maxVel    Velocidad máxima a la que se mueve
	 * @param velocity  Vector velocidad que tiene
	 * @param gameStage Pantalla del juego en la que aparece
	 */
	public SlimePurple(BufferedImage texture, Vector position, double maxVel, Vector velocity, GameStage gameStage) {
		super(texture, position, maxVel, velocity, gameStage);
		slimePurple = true;
		this.velocity = velocity.scale(maxVel);
	}

	/**
	 * Método para destruir a los slimes, sí es grande generará pequeños, y sino,
	 * los destruirá. Según cuál sea dará más puntuación
	 */
	@Override
	public void destroy() {
		int score = 0;
		if (texture == Assets.miniSlime) {
			slimePurple = false;
			score = MINISLIME_SCORE;

		} else {
			slimePurple = true;
			score = SLIME_SCORE;
		}
		if (!super.instakill()) {
			if (slimePurple) {
				gameStage.divideSlime(this);
			}
		}
		gameStage.addScore(super.doubleScore(score), position);

		super.destroy();
	}

	/**
	 * Método para devolver sí es un slime grande o minislime
	 * 
	 * @return boolean Indica sí és un slime pequeño o no
	 */
	public static boolean getSlimePurple() {
		return slimePurple;
	}

}
