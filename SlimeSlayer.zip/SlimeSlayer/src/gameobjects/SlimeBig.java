package gameobjects;

import java.awt.image.BufferedImage;

import math.Vector;
import stages.GameStage;

/**
 * Clase del Slime grande
 * 
 * @author Víctor Villalón
 * @version 1.0
 */
public class SlimeBig extends Slimes {
	private static final int SLIME_SCORE = 40;
	private int hit;

	/**
	 * Constructor del slime
	 * 
	 * @param texture   Imagen que tendrá el slime
	 * @param position  Vector posición en el que aparecerá
	 * @param maxVel    Velocidad máxima a la que se mueve
	 * @param velocity  Vector velocidad que tiene
	 * @param gameStage Pantalla del juego en la que aparece
	 */
	public SlimeBig(BufferedImage texture, Vector position, double maxVel, Vector velocity, GameStage gameStage) {
		super(texture, position, maxVel, velocity, gameStage);
		this.velocity = velocity.scale(maxVel);
		hit = 0;
	}

	/**
	 * Método para destruir el slime si ha recibido 3 hits o sí se tiene el powerUp
	 * de instakill
	 */
	@Override
	public void destroy() {
		if (!super.instakill()) {
			hit++;
			if (hit == 3) {
				gameStage.addScore(super.doubleScore(SLIME_SCORE), position);
				super.destroy();
			}
		} else {
			gameStage.addScore(super.doubleScore(SLIME_SCORE), position);
			super.destroy();
		}
	}

}