package gameobjects;

import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.geom.AffineTransform;
import java.awt.image.BufferedImage;

import graphics.Assets;
import graphics.Sound;
import math.Vector;
import stages.GameStage;
import stages.MenuStage;
import ui.Action;

/**
 * Clase para crear los PowerUps
 * 
 * @author Javier Valero
 * @version 1.0
 */
public class PowerUp extends GameObject {

	private static final int DURATION = 9000;
	private Action action;
	private Sound powerUpSound;
	private BufferedImage typeTexture;
	private Chronometer timer;

	/**
	 * Constructor del Power Up
	 * 
	 * @param position  Vector posición del Power Up
	 * @param texture   Imagen del Power Up
	 * @param action    Acción que realiza
	 * @param gameState Pantalla del juego en la que aparece
	 */
	public PowerUp(Vector position, BufferedImage texture, Action action, GameStage gameState) {
		super(Assets.orb, position, 0, new Vector(), gameState);
		this.action = action;
		this.typeTexture = texture;
		this.timer = new Chronometer();
		timer.run(DURATION);
		powerUpSound = new Sound(Assets.powerUp);
		if (MenuStage.muted) {
			powerUpSound.mute();
		} else {
			powerUpSound.changeVolume(-10.0f);
		}
	}

	/**
	 * Método que ejecuta la acción y el sonido de recoger el Power up
	 */
	void executeAction() {
		action.doAction();
		powerUpSound.play();
	}

	/**
	 * Método para actualizar el cronónemtro y comprobar sí ha sido recogido
	 */
	@Override
	public void update() {
		angle += 0.03;
		timer.update();
		if (!timer.isRunning()) {
			this.destroy();
		}
		collidesWith();

	}

	/**
	 * Método para dibujar el Power Up
	 */
	@Override
	public void draw(Graphics g) {
		Graphics2D g2d = (Graphics2D) g;

		at = AffineTransform.getTranslateInstance(
				position.getX() + Assets.orb.getWidth() / 2 - typeTexture.getWidth() / 2,
				position.getY() + Assets.orb.getHeight() / 2 - typeTexture.getHeight() / 2);

		at.rotate(angle, typeTexture.getWidth() / 2, typeTexture.getHeight() / 2);

		g.drawImage(Assets.orb, (int) position.getX(), (int) position.getY(), null);

		g2d.drawImage(typeTexture, at, null);
	}

}
