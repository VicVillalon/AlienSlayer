package gameobjects;

import java.awt.image.BufferedImage;

import math.Vector;
import stages.GameStage;

/**
 * Clase del slime básico
 * 
 * @author Víctor Villalón
 * @version 1.0
 */
public class Slime extends Slimes {
	private static final int SLIME_SCORE = 20;

	/**
	 * Constructor del slime
	 * 
	 * @param texture   Imagen del slime
	 * @param position  Vector posición del slime
	 * @param maxVel    Velocidad máxima
	 * @param velocity  Vector posición
	 * @param gameStage Pantalla del juego en la que aparece
	 */
	public Slime(BufferedImage texture, Vector position, double maxVel, Vector velocity, GameStage gameStage) {
		super(texture, position, maxVel, velocity, gameStage);
		this.velocity = velocity.scale(maxVel);
	}

	/**
	 * Método sobreescrito añadiendo la puntuación del slime y destruyéndolo
	 */
	@Override
	public void destroy() {
		gameStage.addScore(super.doubleScore(SLIME_SCORE), position);
		super.destroy();
	}

}