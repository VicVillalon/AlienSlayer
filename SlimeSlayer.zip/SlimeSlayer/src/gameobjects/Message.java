package gameobjects;

import java.awt.AlphaComposite;
import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;

import graphics.Text;
import math.Vector;
import stages.GameStage;

/**
 * Clase para generar un mensaje en pantalla
 * 
 * @author Víctor Villalón
 * @version 1.0
 */
public class Message {
	private GameStage gameState;
	private float alpha;
	private Vector position;
	private String text;
	private Color color;
	private boolean center;
	private boolean fade;
	private Font font;
	private final float DIFALPHA = 0.01f;

	/**
	 * Constructor del mensaje
	 * 
	 * @param position  Vector posición del mensaje
	 * @param fade      Booleana para indicar sí tiene que desaparecer o no
	 * @param text      Texto
	 * @param color     Color del texto
	 * @param center    Parámetro para centrar el texto
	 * @param font      Fipo de fuente
	 * @param gameState El escenario del juego
	 */
	public Message(Vector position, boolean fade, String text, Color color, boolean center, Font font,
			GameStage gameState) {
		this.font = font;
		this.gameState = gameState;
		this.text = text;
		this.position = position;
		this.fade = fade;
		this.color = color;
		this.center = center;

		if (fade) {
			alpha = 1;
		} else {
			alpha = 0;
		}

	}

	/**
	 * Método para dibujar el mensaje creando un texto
	 * 
	 * @param g2d Recurso para dibujar los mensajes del juego
	 */
	public void draw(Graphics2D g2d) {
		g2d.setComposite(AlphaComposite.getInstance(AlphaComposite.SRC_OVER, alpha));

		Text.drawText(g2d, text, position, center, color, font);

		g2d.setComposite(AlphaComposite.getInstance(AlphaComposite.SRC_OVER, 1));

		position.setY(position.getY() - 1);

		if (fade) {
			alpha -= DIFALPHA;
		} else {
			alpha += DIFALPHA;
		}

		if (fade && alpha < 0) {
			gameState.getMessages().remove(this);
		}

		if (!fade && alpha > 1) {
			fade = true;
			alpha = 1;
		}

	}

}
