package gameobjects;

import java.awt.image.BufferedImage;

import graphics.Assets;

/**
 * Clase para demarcar los tipos de los powerUps
 * 
 * @author Javier Valero
 * @version 1.0
 */
public enum PowerUpTypes {
	LIFE("+1 LIFE!", Assets.life), SCORE_X2("SCORE X2!", Assets.doubleScore),
	FASTER_FIRE("FAST FIRE!", Assets.fastFire), INSTA_KILL("INSTA KILL!", Assets.instaKill);

	public String text;
	public BufferedImage texture;

	/**
	 * Constructor privado
	 * 
	 * @param text    Texto del powerUp
	 * @param texture Imagen del powerUp
	 */
	private PowerUpTypes(String text, BufferedImage texture) {
		this.text = text;
		this.texture = texture;
	}

}
