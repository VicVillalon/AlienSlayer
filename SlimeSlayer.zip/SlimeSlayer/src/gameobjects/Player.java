package gameobjects;

import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.geom.AffineTransform;
import java.awt.image.BufferedImage;

import graphics.Assets;
import graphics.Sound;
import input.KeyBoard;
import math.Vector;
import stages.GameStage;
import stages.MenuStage;
import window.MainWindow;

/**
 * Clase para generar un mensaje en pantalla
 * 
 * @author Javier Valero
 * @version 1.0
 */
public class Player extends GameObject {

	private Vector heading;
	private Vector acceleration;
	private final double ACC = 0.2;
	private final long FIRERATE = 250;

	private boolean accelerate = false;
	private boolean desaccelerate = false;
	private Chronometer chronometer;

	public static final long FLICKER_TIME = 200;
	public static final long SPAWNING_TIME = 2000;
	private static final long POWERUP_TIME = 7000;

	private boolean spawning, visible;
	private Chronometer spawnTime, flickerTime, instakillTime, doubleScoreTime, fastFireTime;

	public static boolean instakillOn, doubleScoreOn, fastFireOn;

	private double auxMaxVel, hitMaxVel;

	private Sound shoot, hit;

	/**
	 * Constructor de la clase
	 * 
	 * @param texture   Imatge del jugador
	 * @param position  Posició del jugador
	 * @param maxVel    Maxima velocitat de moviment del jugador
	 * @param velocity  Velocitat de moviment del jugador
	 * @param gameState Escenari de joc actual
	 */
	public Player(BufferedImage texture, Vector position, double maxVel, Vector velocity, GameStage gameState) {
		super(texture, position, maxVel, velocity, gameState);
		this.auxMaxVel = maxVel;
		hitMaxVel = maxVel * 1.5;
		heading = new Vector(0, 1);
		acceleration = new Vector();
		chronometer = new Chronometer();
		spawnTime = new Chronometer();
		flickerTime = new Chronometer();
		instakillTime = new Chronometer();
		doubleScoreTime = new Chronometer();
		fastFireTime = new Chronometer();
		shoot = new Sound(Assets.shootSound);
		hit = new Sound(Assets.hit);
		if (MenuStage.muted) {
			shoot.mute();
			hit.mute();
		} else {
			shoot.changeVolume(-25.0f);
			hit.changeVolume(-8.0f);
		}

	}

	/**
	 * Clase que actualitza constantment la posicio i les diferents interaccions a
	 * partir del controls que arriben per teclat
	 */
	@Override
	public void update() {
		if (!spawnTime.isRunning()) {
			spawning = false;
			visible = true;
		}
		if (spawning) {
			if (!flickerTime.isRunning()) {
				flickerTime.run(FLICKER_TIME);
				if (visible == false) {
					visible = true;
				} else {
					visible = false;
				}
			}
		}

		if (KeyBoard.getInstance().isShoot() && !chronometer.isRunning() && spawning == false) {
			gameStage.getMovingObjects().add(0,
					new Shoot(Assets.shoot, getCenter().add(heading.scale(width / 2)), 8, angle, heading, gameStage));
			if (fastFireOn) {
				chronometer.run(FIRERATE / 2);
			} else {
				chronometer.run(FIRERATE);
			}

			shoot.play();
		}
		if (shoot.getFramePosition() > 50000) {
			shoot.stop();
		}

		if (KeyBoard.getInstance().isRight()) {
			angle += Math.PI / 40;
		}
		if (KeyBoard.getInstance().isLeft()) {
			angle -= Math.PI / 40;
		}

		if (KeyBoard.getInstance().isUp()) {
			acceleration = heading.scale(ACC);
			accelerate = true;
			if (KeyBoard.getInstance().isDown()) {
				accelerate = false;
				desaccelerate = false;
				acceleration = (velocity.scale(-1).normalize()).scale(ACC / 2);
			}
		} else {
			if (velocity.getMagnitude() != 0) {
				acceleration = (velocity.scale(-1).normalize()).scale(ACC / 2);
			}
			accelerate = false;
		}
		if (KeyBoard.getInstance().isDown()) {
			acceleration = heading.scale(-ACC);
			desaccelerate = true;
		} else {
			desaccelerate = false;
		}
		velocity = velocity.add(acceleration);

		velocity = velocity.limit(maxVel);

		heading = heading.setDirection(angle - Math.PI / 2);
		position = position.add(velocity);
		if (position.getX() > MainWindow.WIDTH) {
			position.setX(0);
		}
		if (position.getY() > MainWindow.HEIGHT) {
			position.setY(0);
		}
		if (position.getX() < 0) {
			position.setX(MainWindow.WIDTH);
		}
		if (position.getY() < 0) {
			position.setY(MainWindow.HEIGHT);
		}
		instakillTime.update();
		if (instakillOn && !instakillTime.isRunning()) {
			instakillOn = false;
		}
		doubleScoreTime.update();
		if (doubleScoreOn && !doubleScoreTime.isRunning()) {
			doubleScoreOn = false;
		}
		fastFireTime.update();
		if (fastFireOn && !fastFireTime.isRunning()) {
			fastFireOn = false;
		}
		spawnTime.update();
		if (spawnTime.isRunning()) {
			maxVel = hitMaxVel;
		} else {
			maxVel = auxMaxVel;
		}
		flickerTime.update();
		chronometer.update();
		collidesWith();
	}

	/**
	 * Setter del powerUp InstaKill
	 */
	public void setInstaKill() {
		instakillOn = true;
		instakillTime.run(POWERUP_TIME);

	}

	/**
	 * Setter del powerUp DoubleScore
	 */
	public void setDoubleScore() {
		doubleScoreOn = true;
		doubleScoreTime.run(POWERUP_TIME);
	}

	/**
	 * Setter del powerUp FastFire
	 */
	public void setFastFire() {
		fastFireOn = true;
		fastFireTime.run(POWERUP_TIME);
	}

	/**
	 * Método que se ocupa de quitarle una vida al player si es golpeado, si no le
	 * quedan mas vidas, se ejecuta el GameOver
	 */
	@Override
	public void destroy() {
		hit.play();
		spawning = true;
		spawnTime.run(SPAWNING_TIME);

		if (!gameStage.substractLife()) {
			gameStage.gameOver();
			super.destroy();
		}

	}

	/**
	 * Método que recoge el estado del jugador
	 * 
	 * @return boolean Dice si el player esta reapareciendo
	 */
	public boolean isSpawning() {
		return spawning;
	}

	/**
	 * Método que dibuja al jugador y sus ejectos a partir de la posicion
	 * actualizada
	 */
	@Override
	public void draw(Graphics gp) {
		if (visible == false) {
			return;
		}

		Graphics2D g2d = (Graphics2D) gp;

		AffineTransform at1 = AffineTransform.getTranslateInstance(position.getX() + width / 2 + 5,
				position.getY() + height / 2 + 38);
		AffineTransform at2 = AffineTransform.getTranslateInstance(position.getX() + 15,
				position.getY() + height / 2 + 38);
		at1.rotate(angle, -5, -38);
		at2.rotate(angle, width / 2 - 15, -38);

		AffineTransform at3 = AffineTransform.getTranslateInstance(position.getX() + width / 2 + 5,
				position.getY() + height / 2 - 38);
		AffineTransform at4 = AffineTransform.getTranslateInstance(position.getX() + 15,
				position.getY() + height / 2 - 38);
		at3.rotate(angle, -5, 38);
		at4.rotate(angle, width / 2 - 15, 38);

		at = AffineTransform.getTranslateInstance(position.getX(), position.getY());
		at.rotate(angle, width / 2, height / 2);
		g2d.drawImage(Assets.player, at, null);
		if (accelerate) {
			g2d.drawImage(Assets.speed, at1, null);
			g2d.drawImage(Assets.speed, at2, null);
		}
		if (desaccelerate) {
			g2d.drawImage(Assets.speedBack, at3, null);
			g2d.drawImage(Assets.speedBack, at4, null);
		}

	}
}
