package gameobjects;

import java.awt.Graphics;
import java.awt.geom.AffineTransform;
import java.awt.image.BufferedImage;
import java.util.ArrayList;

import graphics.Assets;
import math.Vector;
import stages.GameStage;

/**
 * Clase referente a todos los objetos del juego
 * 
 * @author Javier Valero
 * @version 1.0
 *
 */
public abstract class GameObject {

	protected BufferedImage texture;
	protected Vector position;
	protected Vector velocity;
	protected AffineTransform at;
	protected double angle;
	protected double maxVel;
	protected int width;
	protected int height;
	protected GameStage gameStage;

	private boolean died;

	/**
	 * 
	 * @param texture   Imagen del objeto
	 * @param position  Posicion del objeto
	 * @param maxVel    Máxima velocidad de movimiento del objeto
	 * @param velocity  Vector de velocidad de movimiento
	 * @param gameStage Escenario de juego actual
	 */

	public GameObject(BufferedImage texture, Vector position, double maxVel, Vector velocity, GameStage gameStage) {
		super();
		this.texture = texture;
		this.position = position;
		this.velocity = velocity;
		this.maxVel = maxVel;
		this.gameStage = gameStage;
		width = texture.getWidth();
		height = texture.getHeight();

		angle = 0;

		died = false;
	}

	/**
	 * Método que comprueba la colisión entre todos los objetos del juego y el
	 * propio objeto de la clase, si algún objeto colisiona con el objeto de la
	 * clase pasa a el metodo objectCollision
	 */
	protected void collidesWith() {
		ArrayList<GameObject> movingObjects = gameStage.getMovingObjects();

		for (int i = 0; i < movingObjects.size(); i++) {
			GameObject m = movingObjects.get(i);
			if (m.equals(this)) {
				continue;
			}
			double distance = m.getCenter().substract(getCenter()).getMagnitude();

			if (distance < m.width / 2 + width / 2 && movingObjects.contains(this) && !m.died && !died) {
				objectCollision(m, this);
			}
		}

	}

	/**
	 * A partir de los dos objetos que llegan por parámetro se comprueba el tipo de
	 * los objetos para realizar la acción correcta
	 * 
	 * @param a Primer objeto que colisiona
	 * @param b Segundo objeto que colisiona
	 */
	private void objectCollision(GameObject a, GameObject b) {
		if ((a instanceof Player && b instanceof Shoot) || (a instanceof Shoot && b instanceof Player)) {
			return;
		}
		Player p = null;
		if (a instanceof Player) {
			p = (Player) a;
		} else if (b instanceof Player) {
			p = (Player) b;
		}

		if (p != null && p.isSpawning()) {
			return;
		}

		if (a instanceof Slimes && b instanceof Slimes) {
			return;
		}

		if (!(a instanceof PowerUp || b instanceof PowerUp)) {
			if ((a instanceof Slimes && b instanceof Player) || (a instanceof Player && b instanceof Slimes)) {
				gameStage.playExplosion(getCenter(), Assets.explosionPlayer);
			} else {
				gameStage.playExplosion(getCenter(), Assets.explosionSlime);
			}
			a.destroy();
			b.destroy();
			return;
		}

		if (p != null) {
			if (a instanceof Player) {
				((PowerUp) b).executeAction();
				b.destroy();
			} else if (b instanceof Player) {
				((PowerUp) a).executeAction();
				a.destroy();
			}
		}

	}

	/**
	 * Método que destruye el objeto
	 */
	protected void destroy() {
		died = true;
		gameStage.getMovingObjects().remove(this);
	}

	/**
	 * Recoge la posición central del objeto
	 * 
	 * @return Vector con la posición
	 */
	public Vector getCenter() {
		return new Vector(position.getX() + width / 2, position.getY() + height / 2);
	}

	/**
	 * Recoge el booleano que determina si el objeto esta muerto o no
	 * 
	 * @return boolean Para saber si el objeto esta vivo o muerto
	 */
	public boolean isDead() {
		return died;
	}

	/**
	 * Método abstracto que actualiza el objeto
	 */
	public abstract void update();

	/**
	 * Método abstracto que dibuja el objeto a partir de su actualización
	 * 
	 * @param gp Gráficos del objeto
	 */
	public abstract void draw(Graphics gp);

	/**
	 * Getter de la posicion
	 * 
	 * @return Vector La posición del objeto
	 */
	public Vector getPosition() {
		return position;
	}

	/**
	 * Setter de la posicion
	 * 
	 * @param position Vector posición del objeto
	 */
	public void setPosition(Vector position) {
		this.position = position;
	}

}