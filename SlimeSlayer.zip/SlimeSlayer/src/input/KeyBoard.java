package input;

import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

/**
 * Clase que maneja toda la entrada por teclado, implementa keylistener para
 * recoger la entrada de teclado
 * 
 * @author Víctor Villalón
 * @version 1.0
 */
public class KeyBoard implements KeyListener {

	private static KeyBoard instance;

	private boolean[] keys = new boolean[256];

	/**
	 * Constructor que inicia todos los controles a falso para que una vez toques su
	 * tecla correspondiente se ponga en true y haga su acción
	 */
	private KeyBoard() {
		keys[KeyEvent.VK_UP] = false;
		keys[KeyEvent.VK_DOWN] = false;
		keys[KeyEvent.VK_LEFT] = false;
		keys[KeyEvent.VK_RIGHT] = false;
		keys[KeyEvent.VK_SPACE] = false;
		keys[KeyEvent.VK_ESCAPE] = false;
	}

	public static KeyBoard getInstance() {
		if (instance == null) {
			instance = new KeyBoard();
		}
		return instance;
	}

	/**
	 * Método no implementado
	 * 
	 * @see keyTyped
	 */
	@Override
	public void keyTyped(KeyEvent e) {

	}

	/**
	 * Metodo implementado por keylistener escucha en todo momento si alguna tecla
	 * esta pulsada
	 * 
	 * @see keyPressed
	 */

	@Override
	public void keyPressed(KeyEvent e) {

		keys[e.getKeyCode()] = true;
	}

	/**
	 * Metodo implementado por keylistener escucha en todo momento si alguna tecla
	 * deja de ser pulsada
	 * 
	 * @see keyReleased
	 */
	@Override
	public void keyReleased(KeyEvent e) {

		keys[e.getKeyCode()] = false;

	}

	public boolean isEsc() {
		return keys[KeyEvent.VK_ESCAPE];
	}

	public void setEsc(boolean esc) {
		keys[KeyEvent.VK_ESCAPE] = esc;
	}

	public boolean isRight() {
		return keys[KeyEvent.VK_RIGHT];
	}

	public boolean isShoot() {
		return keys[KeyEvent.VK_SPACE];
	}

	public boolean isUp() {
		return keys[KeyEvent.VK_UP];
	}

	public boolean isDown() {
		return keys[KeyEvent.VK_DOWN];
	}

	public boolean isLeft() {
		return keys[KeyEvent.VK_LEFT];
	}

}
