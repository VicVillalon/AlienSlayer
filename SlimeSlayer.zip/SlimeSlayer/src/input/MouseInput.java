package input;

import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

/**
 * Clase para controlar los inputs del ratón
 * 
 * @author Víctor Villalón
 *
 */
public class MouseInput extends MouseAdapter {

	public static int x, y;

	public static boolean mlb;

	/**
	 * Método para establecer sí se pulsa el botón de uso
	 * 
	 * @see mousePressed
	 */
	@Override
	public void mousePressed(MouseEvent e) {
		if (e.getButton() == MouseEvent.BUTTON1) {
			mlb = true;
		}
	}

	/**
	 * Método para establecer sí se suelta el botón de uso
	 * 
	 * @see mouseReleased
	 */
	@Override
	public void mouseReleased(MouseEvent e) {
		if (e.getButton() == MouseEvent.BUTTON1) {
			mlb = false;
		}
	}

	/**
	 * Método para obtener la posición del ratón
	 * 
	 * @see mouseDragged
	 */
	@Override
	public void mouseDragged(MouseEvent e) {
		x = e.getX();
		y = e.getY();
	}

	/**
	 * Método para obtener la posición del ratón
	 * 
	 * @see mouseMoved
	 */
	@Override
	public void mouseMoved(MouseEvent e) {
		x = e.getX();
		y = e.getY();

	}
}
