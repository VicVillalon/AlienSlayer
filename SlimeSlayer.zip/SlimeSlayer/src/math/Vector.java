package math;

/**
 * Clase que representa un vector en un eje de coordenadas
 * 
 * @author Javier Valero
 * @version 1.0
 */
public class Vector {
	private double x, y;

	/**
	 * Constructor del vector
	 * 
	 * @param x Posición en x en el eje de coordenadas (anchura)
	 * @param y Posición en y en el eje de coordenadas (altura)
	 */
	public Vector(double x, double y) {
		this.x = x;
		this.y = y;
	}

	/**
	 * Constructor vacío que inicializa un vector en 0, 0
	 */
	public Vector() {
		x = 0;
		y = 0;
	}

	/**
	 * Método para generar un vector a partir de otro vector
	 * 
	 * @param v Vector utilizado para generar otor
	 * @return Vector Vector resultante
	 */
	public Vector add(Vector v) {
		return new Vector(x + v.getX(), y + v.getY());
	}

	/**
	 * Método para obtener el vector resultante de la resta de otro vector
	 * 
	 * @param v Vector dado
	 * @return Vector Vector resultante
	 */
	public Vector substract(Vector v) {
		return new Vector(x - v.getX(), y - v.getY());
	}

	/**
	 * Método para escalar un vector a partir de un valor
	 * 
	 * @param value Valor sobre el que multiplicar
	 * @return Vector Vector resultante
	 */
	public Vector scale(double value) {
		return new Vector(x * value, y * value);
	}

	/**
	 * Método para limitar la velocidad del elemento con la velocidad pasada por
	 * parámetro
	 * 
	 * @param value Velocidad pasada por parámetro
	 * @return Vector Vector que limita la velocidad
	 */
	public Vector limit(double value) {
		if (getMagnitude() > value) {
			return this.normalize().scale(value);
		}
		return this;
	}

	/**
	 * Método para obtener la normal del vector
	 * 
	 * @return Vector Vector normal
	 */
	public Vector normalize() {
		return new Vector(x / getMagnitude(), y / getMagnitude());
	}

	/**
	 * Método para obtener el angulo que forma con el eje de coordenadas
	 * 
	 * @return retorna el angulo que forma
	 */
	public double getAngle() {
		return Math.asin(y / getMagnitude());
	}

	/**
	 * Método para reoger la magnitud del vector haciendo la hipotenusa con x e y
	 * 
	 * @return double La hipotenusa del vector
	 */
	public double getMagnitude() {
		return Math.sqrt(x * x + y * y);
	}

	/**
	 * Método para obtener la dirección del objeto a partir del seno y el coseno
	 * multiplicado por la magnitud
	 * 
	 * @param angle Angulo
	 * @return Vector Vector dirección
	 */
	public Vector setDirection(double angle) {
		return new Vector(Math.cos(angle) * getMagnitude(), Math.sin(angle) * getMagnitude());
	}

	/**
	 * Getter de la x
	 * 
	 * @return double Posición de la x
	 */
	public double getX() {
		return x;
	}

	/**
	 * Setter de la x
	 * 
	 * @param x Posición en x
	 */
	public void setX(double x) {
		this.x = x;
	}

	/**
	 * Getter de la Y
	 * 
	 * @return double Posición de la y
	 */
	public double getY() {
		return y;
	}

	/**
	 * Setter de la y
	 * 
	 * @param y Posición de la y
	 */
	public void setY(double y) {
		this.y = y;
	}

}
