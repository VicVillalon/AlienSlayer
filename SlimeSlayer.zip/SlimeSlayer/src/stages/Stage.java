package stages;

import java.awt.Graphics;

/**
 * Clase abstracta que sirve de base para las diferentes pantallas del juego
 * 
 * @author Víctor Villalón
 * @version 1.0
 *
 */
public abstract class Stage {

	private static Stage currentStage = null;

	public Stage() {
	}

	/**
	 * Método para obtener en que pantalla del juego se encuentra
	 * 
	 * @return Stage Devuelve la pantalla actual
	 */
	public static Stage getCurrentStage() {
		return currentStage;
	}

	/**
	 * Método para cambiar la pantalla actual por la nueva
	 * 
	 * @param newStage Pantalla a la cual se tiene que cambiar
	 */
	public static void changeStage(Stage newStage) {
		currentStage = newStage;

	}

	/**
	 * Método abstracto para actualizar
	 */
	public abstract void update();

	/**
	 * Método abstracto para dibujar
	 * 
	 * @param gp Recurso para dibujar los elementos
	 */
	public abstract void draw(Graphics gp);

}
