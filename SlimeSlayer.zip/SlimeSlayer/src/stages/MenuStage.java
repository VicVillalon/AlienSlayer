package stages;

import java.awt.Graphics;
import java.awt.image.BufferedImage;
import java.util.ArrayList;

import javax.swing.JOptionPane;

import graphics.Assets;
import input.KeyBoard;
import ui.Action;
import ui.Button;
import window.MainWindow;

/**
 * Clase para el menú del juego
 * 
 * @author Víctor Villalón
 * 
 * @version 1.0
 */
public class MenuStage extends Stage {

	private ArrayList<Button> buttons;
	public static boolean muted;
	public int pressed;
	BufferedImage texture;

	/**
	 * Constructor del menú, que añade los botones que van a estar
	 */
	public MenuStage() {
		pressed = 0;
		buttons = new ArrayList<Button>();

		buttons.add(new Button(Assets.greyBtn, Assets.greenBtn, MainWindow.WIDTH / 2 - Assets.greyBtn.getWidth() / 2,
				MainWindow.HEIGHT / 2 - Assets.greyBtn.getHeight() * 2, "PLAY", new Action() {
					@Override
					public void doAction() {
						Stage.changeStage(new GameStage());
					}
				}));

		buttons.add(new Button(Assets.greyBtn, Assets.greenBtn, MainWindow.WIDTH / 2 - Assets.greyBtn.getWidth() / 2,
				MainWindow.HEIGHT / 2 + Assets.greyBtn.getHeight() * 2, "EXIT", new Action() {
					@Override
					public void doAction() {
						System.exit(0);
					}
				}));

		buttons.add(new Button(Assets.greyBtn, Assets.greenBtn, MainWindow.WIDTH / 2 - Assets.greyBtn.getWidth() / 2,
				MainWindow.HEIGHT / 2, "SCORE", new Action() {
					@Override
					public void doAction() {
						Stage.changeStage(new ScoreStage());
					}
				}));
		if (muted) {
			texture = Assets.muteOn;
		} else {
			texture = Assets.muteOff;
		}
		buttons.add(
				new Button(texture, texture, MainWindow.WIDTH - Assets.muteOn.getWidth() - 30, 30, "", new Action() {
					@Override
					public void doAction() {
						if (pressed % 8 == 0) {
							muted = buttons.get(3).changeIcon();
						}
						pressed++;
					}
				}));
	}

	/**
	 * Método para ir actualizando el estado de los botones
	 */
	@Override
	public void update() {
		if (KeyBoard.getInstance().isEsc()) {
			KeyBoard.getInstance().setEsc(false);

			int dialog = JOptionPane.YES_NO_OPTION;
			dialog = JOptionPane.showConfirmDialog(null, "Are you sure you wanted to leave the game", "WARNING",
					dialog);
			if (dialog == JOptionPane.YES_OPTION) {
				System.exit(0);
			}
		}
		for (Button b : buttons) {
			b.update();
		}
	}

	/**
	 * Método para dibujar los botones y el fondo
	 */
	@Override
	public void draw(Graphics gp) {
		gp.drawImage(Assets.menuScreen, 0, 0, null);
		for (Button b : buttons) {
			b.draw(gp);
		}
	}

}