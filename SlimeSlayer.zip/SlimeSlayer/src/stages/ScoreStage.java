package stages;

import java.awt.Color;
import java.awt.Graphics;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.PriorityQueue;

import graphics.Assets;
import graphics.Text;
import input.KeyBoard;
import io.JSONParser;
import io.ScoreData;
import math.Vector;
import ui.Action;
import ui.Button;
import window.MainWindow;

/**
 * Clase que muestra las 10 mejores puntuaciones
 * 
 * @author Víctor Villalón
 * @version 1.0
 * 
 */
public class ScoreStage extends Stage {

	private PriorityQueue<ScoreData> highscore;

	private Comparator<ScoreData> scoreComparator;

	private Button returnButton;

	private ScoreData[] auxArray;

	/**
	 * Constructor que genera un botón, un comparador de las puntuaciones (para
	 * ordenarlas) y la lista de los scores
	 */
	public ScoreStage() {
		returnButton = new Button(Assets.greyBtn, Assets.greenBtn, MainWindow.WIDTH - Assets.greyBtn.getWidth() - 50,
				MainWindow.HEIGHT - Assets.greyBtn.getHeight() - 80, "RETURN", new Action() {
					@Override
					public void doAction() {
						Stage.changeStage(new MenuStage());
					}
				});
		scoreComparator = new Comparator<ScoreData>() {
			@Override
			public int compare(ScoreData e1, ScoreData e2) {
				return e1.getScore() < e2.getScore() ? -1 : e1.getScore() > e2.getScore() ? 1 : 0;
			}
		};

		highscore = new PriorityQueue<ScoreData>(10, scoreComparator);

		try {
			ArrayList<ScoreData> dataList = JSONParser.readFile();
			for (ScoreData scoreData : dataList) {
				highscore.add(scoreData);
			}

			while (highscore.size() > 10) {
				highscore.poll();
			}
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
	}

	/**
	 * Método para actualizar el estado del botón
	 */
	@Override
	public void update() {
		if (KeyBoard.getInstance().isEsc()) {
			KeyBoard.getInstance().setEsc(false);
			Stage.changeStage(new MenuStage());
		}
		returnButton.update();

	}

	/**
	 * Método para dibujar a para añadir una puntuación más a la lista, escribiendo
	 * el texto
	 * 
	 * @param gp Recurso para dibujar
	 */
	@Override
	public void draw(Graphics gp) {
		gp.drawImage(Assets.scoreScreen, 0, 0, null);
		returnButton.draw(gp);

		auxArray = highscore.toArray(new ScoreData[highscore.size()]);

		Arrays.sort(auxArray, scoreComparator);

		Vector scorePos = new Vector(MainWindow.WIDTH / 2 - 100, 100);
		Vector datePos = new Vector(MainWindow.WIDTH / 2 + 200, 100);
		Vector userPos = new Vector(MainWindow.WIDTH / 2 - 400, 100);

		Text.drawText(gp, "SCORE", scorePos, false, Color.GREEN, Assets.fontBig);
		Text.drawText(gp, "DATE", datePos, false, Color.GREEN, Assets.fontBig);
		Text.drawText(gp, "USER", userPos, false, Color.GREEN, Assets.fontBig);

		scorePos.setY(scorePos.getY() + 40);
		datePos.setY(datePos.getY() + 40);
		userPos.setY(userPos.getY() + 40);

		for (int i = auxArray.length - 1; i > -1; i--) {

			ScoreData d = auxArray[i];

			Text.drawText(gp, Integer.toString(d.getScore()), scorePos, false, Color.WHITE, Assets.fontMedium);
			Text.drawText(gp, d.getDate(), datePos, false, Color.WHITE, Assets.fontMedium);
			Text.drawText(gp, d.getUser(), userPos, false, Color.WHITE, Assets.fontMedium);

			scorePos.setY(scorePos.getY() + 40);
			datePos.setY(datePos.getY() + 40);
			userPos.setY(userPos.getY() + 40);

		}

	}

}
