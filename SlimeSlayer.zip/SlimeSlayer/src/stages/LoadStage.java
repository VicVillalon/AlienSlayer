package stages;

import java.awt.Color;
import java.awt.Font;
import java.awt.GradientPaint;
import java.awt.Graphics;
import java.awt.Graphics2D;

import graphics.Assets;
import graphics.Loader;
import graphics.Text;
import math.Vector;
import window.MainWindow;

/**
 * Clase para cargar los elementos de forma asíncrona
 * 
 * @author Javier Valero
 * @version 1.0
 */
public class LoadStage extends Stage {
	public static final int BARWIDTH = 500;
	public static final int BARHEIGHT = 50;

	private Thread loadingThread;

	private Font font;

	/**
	 * Constructor de la carga
	 * 
	 * @param loadingThread Thread que carga los recursos
	 */
	public LoadStage(Thread loadingThread) {
		this.loadingThread = loadingThread;
		this.loadingThread.start();
		font = Loader.loadFont("/font/PressStart2P-Regular.ttf", 38);
	}

	/**
	 * Método para actualizar el estado de la carga
	 */
	@Override
	public void update() {
		if (Assets.loaded) {
			Stage.changeStage(new MenuStage());
			try {
				loadingThread.join();
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}

	}

	/**
	 * Método para dibujar la barra de carga
	 */
	@Override
	public void draw(Graphics gp) {
		GradientPaint gradientP = new GradientPaint(MainWindow.WIDTH / 2 - BARWIDTH / 2,
				MainWindow.HEIGHT / 2 - BARHEIGHT / 2, Color.WHITE, MainWindow.WIDTH / 2 + BARWIDTH / 2,
				MainWindow.HEIGHT / 2 + BARHEIGHT / 2, Color.RED);

		Graphics2D g2d = (Graphics2D) gp;
		g2d.setPaint(gradientP);
		float percentage = (Assets.count / Assets.MAX_COUNT);
		g2d.fillRect(MainWindow.WIDTH / 2 - BARWIDTH / 2, MainWindow.HEIGHT / 2 - BARHEIGHT / 2,
				(int) (BARWIDTH * percentage), BARHEIGHT);
		g2d.drawRect(MainWindow.WIDTH / 2 - BARWIDTH / 2, MainWindow.HEIGHT / 2 - BARHEIGHT / 2, BARWIDTH, BARHEIGHT);

		Text.drawText(g2d, "LOADING...", new Vector(MainWindow.WIDTH / 2, MainWindow.HEIGHT / 2 + 25), true,
				Color.WHITE, font);
	}

}
