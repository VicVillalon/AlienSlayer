package stages;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.image.BufferedImage;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;

import javax.swing.JOptionPane;

import gameobjects.Chronometer;
import gameobjects.GameObject;
import gameobjects.Message;
import gameobjects.Player;
import gameobjects.PowerUp;
import gameobjects.PowerUpTypes;
import gameobjects.Slime;
import gameobjects.SlimeBig;
import gameobjects.SlimeFast;
import gameobjects.SlimePurple;
import graphics.Animation;
import graphics.Assets;
import graphics.Sound;
import input.KeyBoard;
import io.JSONParser;
import io.ScoreData;
import math.Vector;
import ui.Action;
import window.MainWindow;

// Juego que guarda en todo momento el estado del juego, se encarga de actualizar, dibujar, etc.. Todos los objetos del juego
/**
 * Clase del escenario del juego
 * 
 * @author Javier Valero
 *
 */
public class GameStage extends Stage {

	private static final int POWERUPTIMER = 15000;
	private static final int DISTANCE_SLIMES = 250;

	private Player player;
	private ArrayList<GameObject> movingObjects = new ArrayList<GameObject>();
	private ArrayList<Animation> explosions = new ArrayList<Animation>();
	private ArrayList<Message> messages = new ArrayList<Message>();
	private GameStage gameStage;

	private int waves;
	private int slimePurple;
	private int slimeBig;
	private int slime;
	private int score;
	private int lives;
	private int limitPowerUps;

	protected static Sound background;
	private Chronometer gameOverTime, powerUpTime;
	private boolean gameOver;

	/**
	 * Constructor del juego, inicializa el jugador y todas las caracteristicas con
	 * las que se empieza el juego
	 */
	public GameStage() {

		player = new Player(Assets.player, new Vector(MainWindow.WIDTH / 2 - Assets.player.getWidth() / 2,
				MainWindow.HEIGHT / 2 - Assets.player.getHeight() / 2), 2.5, new Vector(), this);
		movingObjects.add(player);
		waves = 1;
		slimePurple = 1;
		slime = 3;
		slimeBig = 0;
		lives = 3;
		limitPowerUps = 4;
		background = new Sound(Assets.backgroundMusic);
		if (MenuStage.muted) {
			background.mute();
		} else {
			background.changeVolume(-10.0f);
			background.loop();
		}

		gameOverTime = new Chronometer();
		powerUpTime = new Chronometer();
		gameOver = false;
		gameStage = this;
		startWave();
	}

	/**
	 * Método que inicia una nueva oleada cada vez que se le llama
	 */
	private void startWave() {
		limitPowerUps = 4;
		messages.add(new Message(new Vector(MainWindow.WIDTH / 2, MainWindow.HEIGHT / 2), false, "WAVE " + waves,
				Color.WHITE, true, Assets.fontBig, this));
		double x = 0, y = 0;
		for (int i = 0; i < slimePurple; i++) {
			x = generateSpawnSlimesCoord(x, MainWindow.WIDTH, player.getCenter().getX());
			y = generateSpawnSlimesCoord(y, MainWindow.HEIGHT, player.getCenter().getY());

			BufferedImage texture = Assets.slimePurple;
			movingObjects.add(new SlimePurple(texture, new Vector(x, y), 0.6,
					new Vector(0, 1).setDirection(Math.random() * Math.PI * 2), this));
		}
		for (int i = 0; i < slimeBig; i++) {
			x = generateSpawnSlimesCoord(x, MainWindow.WIDTH, player.getCenter().getX());
			y = generateSpawnSlimesCoord(y, MainWindow.HEIGHT, player.getCenter().getY());

			BufferedImage texture = Assets.slimeBig;
			movingObjects.add(new SlimeBig(texture, new Vector(x, y), 0.4,
					new Vector(0, 1).setDirection(Math.random() * Math.PI * 2), this));
		}

		for (int i = 0; i < slime; i++) {
			x = generateSpawnSlimesCoord(x, MainWindow.WIDTH, player.getCenter().getX());
			y = generateSpawnSlimesCoord(y, MainWindow.HEIGHT, player.getCenter().getY());

			BufferedImage texture = Assets.slime;
			movingObjects.add(new Slime(texture, new Vector(x, y), 0.8,
					new Vector(0, 1).setDirection(Math.random() * Math.PI * 2), this));
		}
		if (waves % 3 == 0) {
			for (int i = 0; i < 2; i++) {
				slimePurple++;
				slimeBig++;
			}
		} else if (waves % 2 == 0) {
			x = generateSpawnSlimesCoord(x, MainWindow.WIDTH, player.getCenter().getX());
			y = generateSpawnSlimesCoord(y, MainWindow.HEIGHT, player.getCenter().getY());
			BufferedImage texture = Assets.slimeFast;
			movingObjects.add(new SlimeFast(texture, new Vector(x, y), 1.3,
					new Vector(0, 1).setDirection(Math.random() * Math.PI * 2), this));

		}
		waves++;
		slime++;

		powerUpTime.run(POWERUPTIMER);
	}

	/**
	 * Método que actualiza constantemente el escenario del juego
	 */
	@Override
	public void update() {
		if (KeyBoard.getInstance().isEsc()) {
			KeyBoard.getInstance().setEsc(false);

			int dialog = JOptionPane.YES_NO_OPTION;
			dialog = JOptionPane.showConfirmDialog(null, "Are you sure you wanted to leave the run", "WARNING", dialog);
			if (dialog == JOptionPane.YES_OPTION) {
				background.stop();
				Stage.changeStage(new MenuStage());
			}
		}

		for (int i = 0; i < movingObjects.size(); i++) {
			movingObjects.get(i).update();
		}
		for (int i = 0; i < explosions.size(); i++) {
			Animation anim = explosions.get(i);
			anim.update();
			if (!anim.isRunning()) {
				explosions.remove(i);
			}

		}
		gameOverTime.update();
		if (gameOver && !gameOverTime.isRunning()) {
			try {
				ArrayList<ScoreData> scoreList = JSONParser.readFile();
				String name = "";
				name = JOptionPane.showInputDialog("Enter your name. If you cancel the score won't save");
				if (name != null) {
					scoreList.add(new ScoreData(score, name));
					JSONParser.writeFile(scoreList);
				}

			} catch (FileNotFoundException e) {
				e.printStackTrace();
			} catch (IOException e) {
				e.printStackTrace();
			}

			background.stop();

			Stage.changeStage(new MenuStage());

		}
		powerUpTime.update();
		if (!powerUpTime.isRunning()) {
			spawnPowerUp();
			powerUpTime.run(POWERUPTIMER);
		}
		for (int i = 0; i < movingObjects.size(); i++) {
			if (movingObjects.get(i) instanceof SlimePurple) {
				return;
			}
			if (movingObjects.get(i) instanceof SlimeBig) {
				return;
			}
			if (movingObjects.get(i) instanceof Slime) {
				return;
			}

		}

		startWave();
	}

	/**
	 * Método que crea las coordenadas de aparicion de los slimes de forma random,
	 * pero con una cierta distancia al jugador
	 * 
	 * @param coord       coordenada (x o y) de un slime
	 * @param max         máxima posición que puede tener la coordenada (X anchura
	 *                    de la pantalla y Y altura de la pantalla)
	 * @param playerCoord coordenada (x o y) del jugador
	 * @return double coordenada del slime
	 */
	private double generateSpawnSlimesCoord(double coord, int max, double playerCoord) {
		double distance = 0;
		do {
			coord = Math.random() * max;
			distance = Math.abs(coord - playerCoord);
		} while (DISTANCE_SLIMES > distance);
		return coord;
	}

	/**
	 * Método que crea un powerUp aleatorio en una posicion aleatoria
	 */
	private void spawnPowerUp() {
		if (limitPowerUps > 0) {
			final int x = (int) ((MainWindow.WIDTH - Assets.orb.getWidth()) * Math.random() + 1);
			final int y = (int) ((MainWindow.HEIGHT - Assets.orb.getHeight()) * Math.random() + 1);

			int index = (int) (Math.random() * (PowerUpTypes.values().length));

			PowerUpTypes p = PowerUpTypes.values()[index];

			final String text = p.text;
			Action action = null;
			Vector position = new Vector(x, y);

			switch (p) {
			case LIFE:
				action = new Action() {
					@Override
					public void doAction() {

						lives++;
						messages.add(
								new Message(position, false, text, Color.BLUE, false, Assets.fontMedium, gameStage));
					}
				};
				break;
			case SCORE_X2:
				action = new Action() {
					@Override
					public void doAction() {
						player.setDoubleScore();
						messages.add(new Message(position, false, text, Color.DARK_GRAY, false, Assets.fontMedium,
								gameStage));
					}
				};
				break;
			case FASTER_FIRE:
				action = new Action() {
					@Override
					public void doAction() {
						player.setFastFire();
						messages.add(
								new Message(position, false, text, Color.YELLOW, false, Assets.fontMedium, gameStage));
					}
				};
				break;
			case INSTA_KILL:
				action = new Action() {
					@Override
					public void doAction() {
						player.setInstaKill();
						messages.add(
								new Message(position, false, text, Color.BLUE, false, Assets.fontMedium, gameStage));
					}
				};
				break;
			default:
				break;
			}

			this.movingObjects.add(new PowerUp(position, p.texture, action, this));
		}
		limitPowerUps--;
	}

	/**
	 * Método que divide el slime Púrpura en 3 slimes minis
	 * 
	 * @param slime Slime Púrpura que se va a dividir
	 */
	public void divideSlime(SlimePurple slime) {
		BufferedImage texture = Assets.miniSlime;

		if (SlimePurple.getSlimePurple()) {
			for (int i = 0; i < 3; i++) {
				movingObjects.add(new SlimePurple(texture,
						new Vector(slime.getPosition().getX() + i * 24, slime.getPosition().getY() + i * 27), 1.0,
						new Vector(0, 1).setDirection(Math.random() * Math.PI * 2), this));
			}
		}

	}

	/**
	 * Método que genera una animación de explosión en la posición pasada por
	 * parámetro
	 * 
	 * @param position  posición donde se generará la explosión
	 * @param explosion Vector de imágenes que forman la animación de la explosión
	 *                  pasada por parámetro
	 */
	public void playExplosion(Vector position, BufferedImage[] explosion) {
		explosions.add(new Animation(explosion, 50,
				position.substract(new Vector(explosion[0].getWidth() / 2, explosion[0].getHeight() / 2))));
	}

	/**
	 * Método que dibuja el escenario del juego a partir de las posiciones
	 * actualizadas
	 */
	@Override
	public void draw(Graphics gp) {
		Graphics2D g2d = (Graphics2D) gp;

		gp.drawImage(Assets.screen, 0, 0, null);

		g2d.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_BILINEAR);

		for (int i = 0; i < movingObjects.size(); i++) {
			movingObjects.get(i).draw(gp);
		}

		for (int i = 0; i < explosions.size(); i++) {
			Animation anim = explosions.get(i);
			g2d.drawImage(anim.getCurrentFrame(), (int) anim.getPosition().getX(), (int) anim.getPosition().getY(),
					null);
		}

		for (int i = 0; i < messages.size(); i++) {
			messages.get(i).draw(g2d);
		}

		drawScore(gp);
		drawLives(gp);
	}

	/**
	 * Método que actualiza la puntuación del juego cada vez que se mata a un slime
	 * y genera un mensaje encima del slime refiriendo a la puntuación ganada por
	 * matar al slime
	 * 
	 * @param value    valor a añadir a la puntuación total, puntuación del slime
	 *                 matado
	 * @param position posicion del slime donde se generará el mensaje
	 */
	public void addScore(int value, Vector position) {
		score += value;
		messages.add(new Message(position, true, "+" + value, Color.WHITE, false, Assets.fontMedium, this));
	}

	/**
	 * Método que dibuja la puntuación actualizada en el escenario
	 * 
	 * @param gp Gráficos donde se dibujara el score
	 */
	private void drawScore(Graphics gp) {
		Vector pos = new Vector(MainWindow.WIDTH - 120, 25);
		String scoreToString = Integer.toString(score);
		for (int i = 0; i < scoreToString.length(); i++) {
			gp.drawImage(Assets.numbers[Integer.parseInt(scoreToString.substring(i, i + 1))], (int) pos.getX(),
					(int) pos.getY(), null);
			pos.setX(pos.getX() + 20);
		}
	}

	/**
	 * Método que dibuja las vidas del jugador actualizadas en el escenario
	 * 
	 * @param gp Gráficos donde se dibujaran las vidas del jugador
	 */
	private void drawLives(Graphics gp) {
		if (lives < 0) {
			return;
		}
		Vector posLife = new Vector(25, 25);
		gp.drawImage(Assets.life, (int) posLife.getX(), (int) posLife.getY(), null);
		gp.drawImage(Assets.numbers[10], (int) posLife.getX() + 40, (int) posLife.getY() + 5, null);

		String livesToString = Integer.toString(lives);
		Vector pos = new Vector(posLife.getX(), posLife.getY());

		for (int i = 0; i < livesToString.length(); i++) {
			int number = 0;
			number = Integer.parseInt(livesToString.substring(i, i + 1));
			if (number < 0) {
				break;
			}
			gp.drawImage(Assets.numbers[number], (int) pos.getX() + 60, (int) pos.getY() + 5, null);
			pos.setX(pos.getX() + 20);
		}
	}

	/**
	 * Método que resta una vida al player
	 * 
	 * @return boolean Dice si al jugador le quedan vidas o no
	 */
	public boolean substractLife() {
		Message gameOverMessage;
		lives--;
		if (lives > 0) {
			gameOverMessage = new Message(new Vector(MainWindow.WIDTH / 2, MainWindow.HEIGHT / 2), true, "-1 LIVE",
					Color.RED, true, Assets.fontMedium, this);
			this.messages.add(gameOverMessage);
		}
		return lives > 0;
	}

	/**
	 * Método que una vez ejecutado, sale un mensaje de "Game Over" y después sale
	 * del escenario del juego para ir al escenario del menú
	 */
	public void gameOver() {
		Message gameOverMessage = new Message(new Vector(MainWindow.WIDTH / 2, MainWindow.HEIGHT / 2), true,
				"GAME OVER", Color.RED, true, Assets.fontBig, this);
		this.messages.add(gameOverMessage);
		gameOverTime.run(3000);
		gameOver = true;
	}

	/**
	 * Getter de la Array de todos los objetos del juego
	 * 
	 * @return Array con todos los objetos del juego
	 */
	public ArrayList<GameObject> getMovingObjects() {
		return movingObjects;
	}

	/**
	 * Getter del jugador
	 * 
	 * @return Player el jugador
	 */
	public Player getPlayer() {
		return player;
	}

	/**
	 * Getter de la Array de todos los mensajes
	 * 
	 * @return Array de todos los mensajes
	 */
	public ArrayList<Message> getMessages() {
		return messages;
	}

}