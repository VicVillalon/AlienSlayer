package window;

import java.awt.Canvas;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.image.BufferStrategy;

import javax.swing.JFrame;

import graphics.Assets;
import input.KeyBoard;
import input.MouseInput;
import stages.LoadStage;
import stages.Stage;

/**
 * Clase principal, donde se muestra la ventana del juego y donde esta el
 * proceso de ejecución
 * 
 * @author Javier Valero
 * @version 1.0
 */
public class MainWindow extends JFrame implements Runnable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	public static final int WIDTH = 1024, HEIGHT = 700;
	private Canvas canvas;
	private Thread thread;
	private boolean running;

	private BufferStrategy bs;
	private Graphics gp;

	private final int FPS = 60;
	private final double TARGETTIME = 1000000000 / FPS;
	private double diff = 0;
	private int averageFPS = FPS;
	private MouseInput mouseInput;

	/**
	 * Constructor de la clase, crea los controles y la ventana, que despues la
	 * dimensiona
	 */
	public MainWindow() {

		setTitle("SLIME SLAYER");
		setSize(WIDTH, HEIGHT);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setResizable(false);
		setLocationRelativeTo(null);
		this.setIconImage(Assets.icon);
		mouseInput = new MouseInput();
		canvas = new Canvas();

		canvas.setPreferredSize(new Dimension(WIDTH, HEIGHT));
		canvas.setMaximumSize(new Dimension(WIDTH, HEIGHT));
		canvas.setMinimumSize(new Dimension(WIDTH, HEIGHT));
		canvas.setFocusable(true);

		canvas.addKeyListener(KeyBoard.getInstance());
		canvas.addMouseListener(mouseInput);
		canvas.addMouseMotionListener(mouseInput);
		add(canvas);
		setVisible(true);
	}

	/**
	 * Main que ejecuta el thread del programa
	 * 
	 * @param args Arguments
	 */
	public static void main(String[] args) {
		new MainWindow().start();

	}

	/**
	 * Método que actualiza en todo momento el escenario
	 */
	public void update() {
		Stage.getCurrentStage().update();
	}

	/**
	 * Método que dibuja todos los gráficos en pantalla
	 */
	public void draw() {
		bs = canvas.getBufferStrategy();

		if (bs == null) {
			canvas.createBufferStrategy(3);
			return;
		}

		gp = bs.getDrawGraphics();

		gp.fillRect(0, 0, WIDTH, HEIGHT);

		Stage.getCurrentStage().draw(gp);

//		Sirve para saber a cuantos frames se reproduce el juego
//		gp.setColor(Color.WHITE);
//
//		gp.drawString("" + AVERAGEFPS, 10, 20);

		gp.dispose();
		bs.show();
	}

	/**
	 * Método que inicia la carga de activos y el estado del juego
	 */
	private void init() {

		Thread loadingThread = new Thread(new Runnable() {
			@Override
			public void run() {
				Assets.init();
			}
		});

		Stage.changeStage(new LoadStage(loadingThread));
	}

	/**
	 * Método implementado de la clase Runnable que esta en constante ejecución,
	 * limitado a 60 entradas por segundo refiriendose a los fps, en esas 60
	 * entradas se encarga de actualizar todas las acciones del juego
	 */

	@Override
	public void run() {

		long now = 0;
		long lastTime = System.nanoTime();
		int frames = 0;
		long time = 0;

		init();

		while (running) {
			now = System.nanoTime();
			diff += (now - lastTime) / TARGETTIME;
			time += (now - lastTime);
			lastTime = now;
			if (diff >= 1) {
				update();
				draw();
				diff--;
				frames++;
			}
			if (time >= 1000000000) {
				averageFPS = frames;
				frames = 0;
				time = 0;
			}
		}
		stop();

	}

	/**
	 * Método de inicialización del hilo que comienza la ejecución del programa
	 */
	public void start() {
		thread = new Thread(this);
		thread.start();
		running = true;
	}

	/**
	 * Método que finaliza la ejecución del programa y termina el hilo de este
	 */
	public void stop() {
		try {
			thread.join();
			running = false;
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}
