package ui;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Rectangle;
import java.awt.image.BufferedImage;

import graphics.Assets;
import graphics.Text;
import input.MouseInput;
import math.Vector;

/**
 * Clase para generar un botón
 * 
 * @author Víctor Villalón
 * @version 1.0
 */
public class Button {

	private BufferedImage mouseOutImg;
	private BufferedImage mouseInImg;
	private boolean mouseIn;
	private Rectangle box;
	private Action action;
	private String text;

	/**
	 * Constructor del botón
	 * 
	 * @param mouseOutImg Imagen del botón cuando no está seleccionado
	 * @param mouseInImg  Imagen del botón cuando está seleccionado
	 * @param x           Posición en el eje x del botón
	 * @param y           Posición en el eje y del botón
	 * @param text        El texto que habrá dentro del botón
	 * @param action      La acción que realiza el botón
	 */
	public Button(BufferedImage mouseOutImg, BufferedImage mouseInImg, int x, int y, String text, Action action) {
		this.mouseInImg = mouseInImg;
		this.mouseOutImg = mouseOutImg;
		this.text = text;
		box = new Rectangle(x, y, mouseInImg.getWidth(), mouseInImg.getHeight());
		this.action = action;
	}

	/**
	 * Método para actualizar la imagen a mostrar del botón, según se este señalando
	 * para establecer que pueda realizar una acción al clicar
	 */
	public void update() {

		if (box.contains(MouseInput.x, MouseInput.y)) {
			mouseIn = true;
		} else {
			mouseIn = false;
		}

		if (mouseIn && MouseInput.mlb) {
			action.doAction();
		}
	}

	/**
	 * Método para dibujar el botón en pantalla con su texto
	 * 
	 * @param gp Recurso que utilizamos para dibujar las imagenes
	 */
	public void draw(Graphics gp) {

		if (mouseIn) {
			gp.drawImage(mouseInImg, box.x, box.y, null);
		} else {
			gp.drawImage(mouseOutImg, box.x, box.y, null);
		}

		Text.drawText(gp, text, new Vector(box.getX() - 50 + (box.getWidth()) / 2, box.getY() - 10 + box.getHeight()),
				false, Color.BLACK, Assets.fontMedium);

	}

	/**
	 * Método para cambiar el icono del bóton
	 * 
	 * @return boolean Indica sí está muteado o no
	 */
	public boolean changeIcon() {
		if (mouseInImg == Assets.muteOff) {
			mouseInImg = Assets.muteOn;
			mouseOutImg = Assets.muteOn;
			return true;
		} else {
			mouseInImg = Assets.muteOff;
			mouseOutImg = Assets.muteOff;
			return false;
		}
	}

}