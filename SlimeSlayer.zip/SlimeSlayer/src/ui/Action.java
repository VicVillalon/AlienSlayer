package ui;

/**
 * Clase abstracta para definir acciones
 * 
 * @author Víctor Villalón
 * @version 1.0
 */
public interface Action {
	/**
	 * Método para realizar una acción
	 */
	public abstract void doAction();

}
