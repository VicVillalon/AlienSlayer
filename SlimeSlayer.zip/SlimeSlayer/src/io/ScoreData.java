package io;

import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * Clase que almacena las puntuaciones de cada partida
 * 
 * @author Víctor Villalón
 * @version 1.0
 */
public class ScoreData {

	private String date;

	private String user;

	private int score;

	/**
	 * Constructor de las puntuaciones
	 * 
	 * @param score Puntuación conseguida
	 * @param user  Usuario que la ha conseguido
	 */

	public ScoreData(int score, String user) {
		super();

		this.user = user;

		this.score = score;

		Date today = new Date(System.currentTimeMillis());

		SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");

		date = sdf.format(today);
	}

	/**
	 * Constructor vacío necesario para parsear en JSON
	 */
	public ScoreData() {

	}

	/**
	 * Getter de la fecha
	 * 
	 * @return date Fecha de la puntuación
	 */
	public String getDate() {
		return date;
	}

	/**
	 * Setter de la fecha
	 * 
	 * @param date Fecha de la puntuación
	 */
	public void setDate(String date) {
		this.date = date;
	}

	/**
	 * Setter del usuario
	 * 
	 * @param user Usuario
	 */
	public void setUser(String user) {
		this.user = user;
	}

	/**
	 * Getter del usuario
	 * 
	 * @return String Nombre del usuari
	 */
	public String getUser() {
		return this.user;
	}

	/**
	 * Getter de la puntuación
	 * 
	 * @return int Puntuació
	 */
	public int getScore() {
		return score;
	}

	/**
	 * Setter de la puntuación
	 * 
	 * @param score Puntuación
	 */
	public void setScore(int score) {
		this.score = score;
	}

}
