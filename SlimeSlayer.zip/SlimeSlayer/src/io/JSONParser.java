package io;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;

import org.json.JSONArray;
import org.json.JSONObject;
import org.json.JSONTokener;

/**
 * Clase para administrar para Parsear en formato JSON
 * 
 * @author Víctor Villalón
 *
 * @version 1.0
 */
public class JSONParser {
	/**
	 * Método para leer un fichero JSON
	 * 
	 * @return ArrayList de ScoreDate con las puntuaciones, fechas y usuarios
	 * @throws FileNotFoundException Excepción que salta cuando no se encuentra el
	 *                               archivo
	 * @see FileNotFoundException
	 */
	public static ArrayList<ScoreData> readFile() throws FileNotFoundException {
		ArrayList<ScoreData> scores = new ArrayList<ScoreData>();

		File jsonFile = new File("data.json");

		if (!jsonFile.isFile() || jsonFile.length() == 0) {
			return scores;
		}

		JSONTokener parser = new JSONTokener(new FileInputStream(jsonFile));
		JSONArray jsonList = new JSONArray(parser);

		for (int i = 0; i < jsonList.length(); i++) {
			JSONObject jsonObject = (JSONObject) jsonList.get(i);
			ScoreData scoreData = new ScoreData();
			scoreData.setScore(jsonObject.getInt("score"));
			scoreData.setDate(jsonObject.getString("date"));
			scoreData.setUser(jsonObject.getString("user"));
			scores.add(scoreData);
		}
		return scores;

	}

	/**
	 * Método para escribir un fichero JSON
	 * 
	 * @param scores ArrayList de ScoreData con los cuales se escribirá el JSON
	 * @throws IOException Excepción en un Input
	 * @see IOException
	 */
	public static void writeFile(ArrayList<ScoreData> scores) throws IOException {
		File out = new File("data.json");

		if (!out.exists()) {
			out.createNewFile();
		}

		JSONArray jsonList = new JSONArray();

		for (ScoreData score : scores) {
			JSONObject jsonObject = new JSONObject();
			jsonObject.put("score", score.getScore());
			jsonObject.put("date", score.getDate());
			jsonObject.put("user", score.getUser());

			jsonList.put(jsonObject);

		}

		BufferedWriter writer = new BufferedWriter(new FileWriter(out.getPath()));
		jsonList.write(writer);
		writer.close();

	}

}
