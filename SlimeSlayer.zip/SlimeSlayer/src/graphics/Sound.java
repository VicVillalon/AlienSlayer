package graphics;

import javax.sound.sampled.Clip;
import javax.sound.sampled.FloatControl;

/**
 * Clase para administrar los sonidos
 * 
 * @author Víctor Villalón
 * @version 1.0
 */
public class Sound {

	private Clip clip;
	private FloatControl volume;

	/**
	 * Constructor de los sonidos
	 * 
	 * @param clip Clip de audio
	 */
	public Sound(Clip clip) {
		super();
		this.clip = clip;
		this.volume = (FloatControl) clip.getControl(FloatControl.Type.MASTER_GAIN);
	}

	/**
	 * Método para reproducir el sonido desde el principio
	 */
	public void play() {
		clip.setFramePosition(0);
		clip.start();
	}

	/**
	 * Método para hacer el sonido loopeable, es decir, que se pueda reproducir en
	 * bucle
	 */
	public void loop() {
		clip.setFramePosition(0);
		clip.loop(Clip.LOOP_CONTINUOUSLY);
	}

	/**
	 * Método para parar el sonido
	 * 
	 */
	public void stop() {
		clip.stop();
	}

	/**
	 * Obtener el frame en el que se encuentra el sonido
	 * 
	 * @return int Frame del clip de audio
	 */
	public int getFramePosition() {
		return clip.getFramePosition();
	}

	/**
	 * Cambiar el volumen del juego
	 * 
	 * @param value Valor del sonido
	 */
	public void changeVolume(float value) {
		volume.setValue(value);
	}

	/**
	 * Método para mutear la música
	 */
	public void mute() {
		volume.setValue(volume.getMinimum());

	}

}
