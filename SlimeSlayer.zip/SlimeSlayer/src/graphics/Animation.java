package graphics;

import java.awt.image.BufferedImage;

import math.Vector;

/**
 * Clase para cargar la animación
 * 
 * @author Javier Valero
 * @version 1.0
 */
public class Animation {
	private BufferedImage[] frames;
	private int change;
	private boolean running;
	private int index;
	private Vector position;
	private long time, lastTime;

	/**
	 * Constructor de la animación
	 * 
	 * @param frames      Las BufferedImages
	 * @param changeFrame El Frame al que tiene que cambiar
	 * @param position    Vector posición
	 */
	public Animation(BufferedImage[] frames, int changeFrame, Vector position) {
		this.frames = frames;
		this.change = changeFrame;
		this.position = position;
		index = 0;
		running = true;
		time = 0;
		lastTime = System.currentTimeMillis();
	}

	/**
	 * Método para ir actualizando el tiempo que está cada imagen
	 */
	public void update() {
		time += System.currentTimeMillis() - lastTime;
		lastTime = System.currentTimeMillis();

		if (time > change) {
			time = 0;
			index++;
			if (index >= frames.length) {
				running = false;
			}
		}
	}

	/**
	 * Método para saber sí la animación sigue en curso
	 * 
	 * @return boolean Indica sí esta activa o no
	 */
	public boolean isRunning() {
		return running;
	}

	/**
	 * Método para obtener el vector de la posición
	 * 
	 * @return Vector Vector de la posición
	 */
	public Vector getPosition() {
		return position;
	}

	/**
	 * Método para saber la imagen que va en el Frame Actual
	 * 
	 * @return BufferedImage La imagen que va ahora
	 */
	public BufferedImage getCurrentFrame() {
		return frames[index];
	}
}
