package graphics;

import java.awt.Font;
import java.awt.image.BufferedImage;

import javax.sound.sampled.Clip;

/**
 * Clase para recoger todos los recursos y pasarlos de forma estática
 * 
 * @author Víctor Villalón
 * @version 1.0
 */
public class Assets {

	public static boolean loaded = false;
	public static float count = 0;
	public final static float MAX_COUNT = 58;
	// Imagen del jugador
	public static BufferedImage player;
	// Imagenes de los pasos
	public static BufferedImage speed, speedBack;
	// Imagen del disparo
	public static BufferedImage shoot;
	// Imagenes de los slimes
	public static BufferedImage slimeBig, slimePurple, miniSlime, slime, slimeFast;
	// explosiones al hit
	public static BufferedImage[] explosionSlime = new BufferedImage[9];
	public static BufferedImage[] explosionPlayer = new BufferedImage[9];
	// numeros
	public static BufferedImage[] numbers = new BufferedImage[11];
	// icono
	public static BufferedImage icon;

	// fondos
	public static BufferedImage screen, menuScreen, scoreScreen;
	// Imagen de la vida
	public static BufferedImage life;

	// Fuentes
	public static Font fontBig, fontMedium;
	// Ui

	public static BufferedImage greenBtn, greyBtn;

	// sounds
	public static Clip shootSound, hit, slimeSound, backgroundMusic, powerUp;

	// Power Ups
	public static BufferedImage orb, doubleScore, fastFire, instaKill;

	// Mute
	public static BufferedImage muteOn, muteOff;

	/**
	 * Mètodo que inicializa los assets
	 */
	public static void init() {
		player = loadImage("/player/player.png");

		icon = loadImage("/icon/icon.png");

		speed = loadImage("/walkEffects/footprints.png");

		speedBack = loadImage("/walkEffects/footprints_back.png");

		shoot = loadImage("/shoots/disparo.png");

		greyBtn = loadImage("/ui/greyButton.png");

		greenBtn = loadImage("/ui/greenButton.png");

		fontBig = loadFont("/font/PressStart2P-Regular.ttf", 42);

		fontMedium = loadFont("/font/PressStart2P-Regular.ttf", 20);

		orb = loadImage("/powerups/orb.png");

		fastFire = loadImage("/powerups/fastFire.png");

		instaKill = loadImage("/powerups/instaKill.png");

		doubleScore = loadImage("/powerups/doubleScore.png");

		slimePurple = loadImage("/slimes/slimePurple.png");

		muteOn = loadImage("/mute/muteOn.png");

		muteOff = loadImage("/mute/muteOff.png");

		slimeBig = loadImage("/slimes/slimeBig.png");

		miniSlime = loadImage("/slimes/miniSlime.png");

		slime = loadImage("/slimes/slime.png");

		for (int i = 0; i < explosionSlime.length; i++) {
			explosionSlime[i] = loadImage("/explosion/" + i + ".png");
		}
		for (int i = 0; i < explosionSlime.length; i++) {
			explosionPlayer[i] = loadImage("/explosionPlayer/" + i + ".png");
		}

		screen = loadImage("/screens/mainScreen.png");

		menuScreen = loadImage("/screens/menuScreen.png");

		scoreScreen = loadImage("/screens/scoreScreen.png");

		slimeFast = loadImage("/slimes/slimeFast.png");

		life = loadImage("/heart/heart.png");

		for (int i = 0; i < numbers.length; i++) {
			numbers[i] = loadImage("/numbers/" + i + ".png");
		}

		shootSound = loadSound("/sounds/shoot.wav");

		hit = loadSound("/sounds/hit.wav");

		slimeSound = loadSound("/sounds/slime.wav");

		powerUp = loadSound("/sounds/powerUp.wav");

		backgroundMusic = loadSound("/sounds/backgroundMusic.wav");

		loaded = true;

	}

	/**
	 * Método que carga las imagenes y cuenta cuantos recursos se han ido sumando
	 * 
	 * @param path URL de la imagen
	 * @return BufferedImage Imagen que ha cargado
	 */
	public static BufferedImage loadImage(String path) {
		count++;
		return Loader.ImageLoader(path);
	}

	/**
	 * Método que carga las fuentes y cuenta cuantos recursos se han ido sumando
	 * 
	 * @param path URL de la fuente
	 * @param size Tamaño de la fuente
	 * @return Font Fuente que ha cargado
	 */
	public static Font loadFont(String path, int size) {
		count++;
		return Loader.loadFont(path, size);
	}

	/**
	 * Método que carga los archivos de audio
	 * 
	 * @param path URL del audio
	 * @return Clip Clip de sonido
	 */
	public static Clip loadSound(String path) {
		count++;
		return Loader.loadSound(path);
	}
}
