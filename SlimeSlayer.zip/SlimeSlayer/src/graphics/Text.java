package graphics;

import java.awt.Color;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.Graphics;

import math.Vector;

/**
 * Clase que genera un texto
 * 
 * @author Víctor Villalón
 * @version 1.0
 */
public class Text {
	/**
	 * Dibuja el texto dados los parametros
	 * 
	 * @param g      Recurso que para dibujar en pantalla
	 * @param text   Texto a escribir
	 * @param pos    Vector posición del texto
	 * @param center Indica sí tiene que estar centrado o no
	 * @param color  Color del texto
	 * @param font   Fuente del texto
	 */
	public static void drawText(Graphics g, String text, Vector pos, boolean center, Color color, Font font) {
		g.setColor(color);
		g.setFont(font);
		Vector position = new Vector(pos.getX(), pos.getY());

		if (center) {
			// dimensiones de texto
			FontMetrics fm = g.getFontMetrics();
			position.setX(position.getX() - fm.stringWidth(text) / 2);
			position.setX(position.getY() - fm.getHeight() / 2);
		}
		g.drawString(text, (int) position.getX(), (int) position.getY());
	}

}
